from tls_client import Session
import json
import random
from colorama import Fore,init
import time
from datetime import datetime


class log:
    @staticmethod
    def error(message):
        t = datetime.now().strftime("%H:%M:%S")
        print(f"{t} [error] {Fore.RESET}{message}")

    @staticmethod
    def success(message):
        t = datetime.now().strftime("%H:%M:%S")
        print(f"{t} [success] {Fore.RESET}{message}")

    @staticmethod
    def info(message):
        t = datetime.now().strftime("%H:%M:%S")
        print(f"{t} [info] {Fore.RESET}{message}")

    @staticmethod
    def warning(message):
        t = datetime.now().strftime("%H:%M:%S")
        print(f"{t} [warning] {Fore.RESET}{message}")


class giveawayboat:
    def __init__(self, token, guild_id, bot_id, channel_id, message_id):
        self.session = Session(
            client_identifier="okhttp4_android_10",
            random_tls_extension_order=True
        )
        self.ua = "Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727)"
        self.super_prop = "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLU5SIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEwNi4wLjAuMCBTYWZhcmkvNTM3LjM2IiwiYnJvd3Nlcl92ZXJzaW9uIjoiMTA2LjAuMC4wIiwib3NfdmVyc2lvbiI6IjEwIiwicmVmZXJyZXIiOiJodHRwczovL2Rpc2NvcmQuY29tL2NoYW5uZWxzL0BtZSIsInJlZmVycmluZ19kb21haW4iOiIiLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6MjQ3OTI5LCJjbGllbnRfZXZlbnRfc291cmNlIjoibnVsbCJ9"
        self.token = token


        self.guild_id = guild_id
        self.bot_id = bot_id
        self.channel_id = channel_id
        self.message_id = message_id





        self.session.headers = {
            "Host": "discord.com",
            "User-Agent": self.ua,
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-GB,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "Referer": "https://discord.com/app",
            "Content-Type": "application/json",
            "Origin": "https://discord.com",
            "Connection": "keep-alive",
            "Authorization": self.token,
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "TE": "trailers",
            "X-Debug-Options": "bugReporterEnabled",
            "X-Discord-Locale": "en-GB",
            "X-Discord-Timezone": "America/Halifax",
            "X-Super-Properties": self.super_prop,
        }


    def start(self):

        data = {
            "type": 3,
            "nonce": int(random.randint(1000000000000000000, 9999999999999999999)),
            "guild_id": self.guild_id,
            "channel_id": self.channel_id,
            "message_flags": 0,
            "message_id": self.message_id,
            "application_id": self.bot_id,
            "session_id": str(random.randbytes(16).hex()),
            "data": {
                "component_type": 2,
                "custom_id": "giveaway_message"
            }

        }
        
        r = self.session.post(
            "https://discord.com/api/v9/interactions",
                              json=data,
                              )
        
        time.sleep(2)
        
        if r.status_code == 204:
            log.success(f"Entered giveaway with token: {self.token}")

        else:
            log.error(f"Failed to enter giveaway with token: {self.token}")