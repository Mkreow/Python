import json
from main import giveawayboat

def readTokens():
    with open("tokens.txt", "r") as token_file:
        return token_file.read().splitlines()

def loadConfig():
    with open("config.json", "r") as config_file:
        return json.load(config_file)

if __name__ == "__main__":
    tokens = readTokens()
    config = loadConfig()

    guild_id = config["guild_id"]
    bot_id = config["bot_id"]
    channel_id = config["channel_id"]
    message_id = config["message_id"]

    for token in tokens:
        giveawayboat(token, guild_id, bot_id, channel_id, message_id).start()